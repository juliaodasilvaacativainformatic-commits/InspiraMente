# Como gerar o APK pelo telefone

1. Crie uma conta no GitHub e um repositório novo (pode ser privado).
2. No navegador do telefone, abra o repositório e escolha **Add file > Upload files**.
3. Extraia este ZIP e envie **o conteúdo da pasta InspiraMente**, incluindo a pasta `.github`.
4. Faça o commit na branch `main`.
5. Abra a aba **Actions** do repositório.
6. Abra **Build InspiraMente APK**. O workflow será executado automaticamente.
7. Quando aparecer um visto verde, abra a execução e procure **Artifacts**.
8. Baixe **InspiraMente-APK** e extraia o ZIP do artifact.
9. Toque em `app-debug.apk` para instalar.

Observação: o APK gerado é uma versão de teste (debug). Para publicar na Google Play, depois será necessário gerar uma versão release assinada/AAB.
