package com.inspiramente.app

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { InspiraMenteApp() }
    }
}

private val Ink = Color(0xFF182033)
private val Accent = Color(0xFF7C5CFC)
private val Soft = Color(0xFFF5F3FF)

@Composable
fun InspiraMenteApp() {
    val context = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var selectedCategory by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var current by remember { mutableStateOf(QuoteRepository.quotes.first()) }
    val favorites = remember { mutableStateListOf<Int>() }

    MaterialTheme(colorScheme = lightColorScheme(primary = Accent, background = Color.White, surface = Color.White)) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = { Text("InspiraMente", fontWeight = FontWeight.Bold) },
                    actions = {
                        IconButton(onClick = { tab = 3 }) { Icon(Icons.Default.Search, "Pesquisar") }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf(Icons.Default.Home to "Início", Icons.Default.GridView to "Categorias", Icons.Default.Favorite to "Favoritos", Icons.Default.Search to "Pesquisar").forEachIndexed { i, pair ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(pair.first, null) }, label = { Text(pair.second) })
                    }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (tab) {
                    0 -> HomeScreen(current, favorites.contains(current.id), { favorites.toggle(current.id) }, {
                        current = QuoteRepository.quotes.random()
                    }, { q -> shareQuote(context, q) }, { q -> copyQuote(context, q) })
                    1 -> CategoryScreen(selectedCategory, { selectedCategory = it; tab = 3 })
                    2 -> QuoteListScreen("Favoritos", QuoteRepository.quotes.filter { favorites.contains(it.id) }, favorites, { favorites.toggle(it) }, { q -> shareQuote(context, q) })
                    3 -> SearchScreen(query, { query = it }, selectedCategory, QuoteRepository.quotes.filter { q ->
                        (selectedCategory == null || q.category == selectedCategory) && (query.isBlank() || q.text.contains(query, true) || q.author.contains(query, true))
                    }, favorites, { favorites.toggle(it) }, { q -> shareQuote(context, q) })
                }
            }
        }
    }
}

private fun MutableList<Int>.toggle(id: Int) { if (contains(id)) remove(id) else add(id) }

@Composable
private fun HomeScreen(q: Quote, liked: Boolean, onLike: () -> Unit, onNew: () -> Unit, onShare: (Quote) -> Unit, onCopy: (Quote) -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Text("Frase do momento", color = Accent, fontWeight = FontWeight.SemiBold)
        QuoteCard(q, liked, onLike, onShare, onCopy)
        Button(onClick = onNew, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(8.dp)); Text("Nova frase")
        }
        Text("Explore por categoria", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Motivação", "Humor", "Amor").forEach { c -> AssistChip(onClick = {}, label = { Text(c) }) }
        }
    }
}

@Composable
private fun QuoteCard(q: Quote, liked: Boolean, onLike: () -> Unit, onShare: (Quote) -> Unit, onCopy: (Quote) -> Unit) {
    Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Soft), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("“", fontSize = 52.sp, color = Accent, fontWeight = FontWeight.Bold)
            Text(q.text, fontSize = 24.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, color = Ink)
            Spacer(Modifier.height(18.dp))
            Text("— ${q.author}", fontSize = 14.sp, color = Color.Gray, textAlign = TextAlign.Center)
            Spacer(Modifier.height(6.dp))
            AssistChip(onClick = {}, label = { Text(q.category) })
            Row(horizontalArrangement = Arrangement.Center) {
                IconButton(onClick = onLike) { Icon(if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favoritar") }
                IconButton(onClick = { onCopy(q) }) { Icon(Icons.Default.ContentCopy, "Copiar") }
                IconButton(onClick = { onShare(q) }) { Icon(Icons.Default.Share, "Partilhar") }
            }
        }
    }
}

@Composable
private fun CategoryScreen(selected: String?, onSelect: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Categorias", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(QuoteRepository.categories) { category ->
                Card(Modifier.fillMaxWidth().clickable { onSelect(category) }, shape = RoundedCornerShape(18.dp)) {
                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(category, fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                        Icon(Icons.Default.ChevronRight, null)
                    }
                }
            }
        }
    }
}

@Composable
private fun QuoteListScreen(title: String, quotes: List<Quote>, favorites: MutableList<Int>, toggle: (Int) -> Unit, share: (Quote) -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        if (quotes.isEmpty()) Text("Ainda não há frases guardadas.", color = Color.Gray)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(quotes) { q ->
                Card(shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Text(q.text, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                        Text("— ${q.author}", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                        Row {
                            IconButton(onClick = { toggle(q.id) }) { Icon(Icons.Default.Favorite, "Remover dos favoritos") }
                            IconButton(onClick = { share(q) }) { Icon(Icons.Default.Share, "Partilhar") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchScreen(query: String, setQuery: (String) -> Unit, category: String?, quotes: List<Quote>, favorites: MutableList<Int>, toggle: (Int) -> Unit, share: (Quote) -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        OutlinedTextField(value = query, onValueChange = setQuery, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Pesquisar frases, autores...") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        Spacer(Modifier.height(14.dp))
        if (category != null) Text("Categoria: $category", color = Accent, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(quotes) { q ->
                Card(shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Text(q.text, fontSize = 17.sp)
                        Text("— ${q.author}", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                        Row {
                            IconButton(onClick = { toggle(q.id) }) { Icon(if (favorites.contains(q.id)) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favoritar") }
                            IconButton(onClick = { share(q) }) { Icon(Icons.Default.Share, "Partilhar") }
                        }
                    }
                }
            }
        }
    }
}

private fun shareQuote(context: android.content.Context, q: Quote) {
    val text = "“${q.text}”\n— ${q.author}\n\nInspiraMente"
    context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }, "Partilhar frase"))
}

private fun copyQuote(context: android.content.Context, q: Quote) {
    val clipboard = context.getSystemService(android.content.ClipboardManager::class.java)
    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Frase", "“${q.text}” — ${q.author}"))
    Toast.makeText(context, "Frase copiada", Toast.LENGTH_SHORT).show()
}
