# InspiraMente — Android v1.0

Aplicação Android de frases motivadoras, sentimentos, humor, amor, filosofia, fé, estudos, amizade e mensagens de bom dia/boa noite.

## Stack
- Kotlin 2.4.10
- Jetpack Compose
- Material 3
- Android API 36
- Min SDK 24
- Gradle/AGP 9.4.0

## Funcionalidades da V1
- Frase do momento
- Nova frase aleatória
- Categorias
- Pesquisa por frase/autor
- Favoritos em memória durante a sessão
- Copiar frase
- Partilhar por outras aplicações
- Interface preparada para modo escuro e expansão futura

## Próxima evolução
1. Persistir favoritos com DataStore/Room.
2. Migrar catálogo para JSON/Room para suportar centenas ou milhares de frases.
3. Criar gerador de imagens para Status/Stories.
4. Notificação de frase diária.
5. Adicionar filtros e histórico.
6. Adicionar painel de conteúdo para novas frases.
7. Preparar anúncios/Premium, se desejado.
8. Gerar AAB assinado e publicar na Google Play.

## Abrir
Abra a pasta no Android Studio e aguarde a sincronização do Gradle. Instale o SDK Android 36.

## Identidade provisória
Nome: InspiraMente
Conceito: uma biblioteca diária de palavras para motivar, refletir, sorrir e partilhar.
Paleta inicial: roxo #7C5CFC, azul-marinho #182033, branco e lavanda #F5F3FF.
