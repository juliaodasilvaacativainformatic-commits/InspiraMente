# InspiraMente — compilação online

Este projeto foi preparado para gerar um APK diretamente no GitHub Actions, sem Android Studio e sem AndroidIDE.

Stack: Kotlin + Jetpack Compose + AGP 8.13.2 + Kotlin 2.3.20 + Gradle 8.13 + Java 17.
