# Política de Privacidade — InspiraMente (rascunho)

**Última atualização:** 24 de setembro de 2026

O InspiraMente foi concebido para apresentar frases e permitir ao utilizador pesquisar, guardar e partilhar conteúdo.

### Dados
A versão inicial não exige criação de conta e não envia frases pesquisadas para um servidor.

### Partilha
Quando o utilizador escolhe partilhar uma frase, o Android abre a aplicação escolhida pelo utilizador. A transmissão do conteúdo passa a seguir as políticas dessa aplicação.

### Publicidade e analytics
A versão inicial não integra publicidade nem analytics. Se esses serviços forem adicionados no futuro, esta política deverá ser atualizada antes da publicação.

### Contacto
Substituir esta linha pelo e-mail oficial do responsável pelo aplicativo antes da publicação.
